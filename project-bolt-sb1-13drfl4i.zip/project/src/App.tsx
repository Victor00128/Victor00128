import React, { useState } from 'react';
import { MessageSquare, Sparkles, Globe } from 'lucide-react';
import ChatWindow from './components/ChatWindow';
import ChatInput from './components/ChatInput';
import LanguageSelector from './components/LanguageSelector';
import { Message } from './types/chat';
import { apiService } from './services/apiService';
import { LanguageDetector, supportedLanguages } from './services/languageDetection';

function App() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [currentLanguage, setCurrentLanguage] = useState('es');
  const [autoDetect, setAutoDetect] = useState(true);

  const generateId = () => `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  const handleSendMessage = async (text: string) => {
    const userMessage: Message = {
      id: generateId(),
      text,
      isUser: true,
      timestamp: Date.now(),
    };

    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setIsLoading(true);

    try {
      // Automatic language detection for better user experience
      let detectedLanguage = currentLanguage;
      if (autoDetect) {
        detectedLanguage = LanguageDetector.detectLanguage(text);
        if (detectedLanguage !== currentLanguage) {
          setCurrentLanguage(detectedLanguage);
        }
      }

      const languageConfig = LanguageDetector.getLanguageConfig(detectedLanguage);
      const response = await apiService.sendMessage(text, languageConfig.systemPrompt);
      
      const responseMessage: Message = {
        id: generateId(),
        text: response,
        isUser: false,
        timestamp: Date.now(),
      };

      setMessages((prevMessages) => [...prevMessages, responseMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      
      // Localized error messages
      const errorMessages: Record<string, string> = {
        es: `Lo siento, ha ocurrido un error: ${error instanceof Error ? error.message : 'Error desconocido'}. Por favor, inténtalo de nuevo.`,
        en: `Sorry, an error occurred: ${error instanceof Error ? error.message : 'Unknown error'}. Please try again.`,
        fr: `Désolé, une erreur s'est produite: ${error instanceof Error ? error.message : 'Erreur inconnue'}. Veuillez réessayer.`,
        de: `Entschuldigung, ein Fehler ist aufgetreten: ${error instanceof Error ? error.message : 'Unbekannter Fehler'}. Bitte versuchen Sie es erneut.`,
        it: `Spiacente, si è verificato un errore: ${error instanceof Error ? error.message : 'Errore sconosciuto'}. Per favore riprova.`,
        pt: `Desculpe, ocorreu um erro: ${error instanceof Error ? error.message : 'Erro desconhecido'}. Por favor, tente novamente.`,
        ru: `Извините, произошла ошибка: ${error instanceof Error ? error.message : 'Неизвестная ошибка'}. Пожалуйста, попробуйте еще раз.`,
        zh: `抱歉，发生了错误：${error instanceof Error ? error.message : '未知错误'}。请重试。`,
        ja: `申し訳ございませんが、エラーが発生しました：${error instanceof Error ? error.message : '不明なエラー'}。もう一度お試しください。`,
        ko: `죄송합니다. 오류가 발생했습니다: ${error instanceof Error ? error.message : '알 수 없는 오류'}. 다시 시도해 주세요.`,
        ar: `عذراً، حدث خطأ: ${error instanceof Error ? error.message : 'خطأ غير معروف'}. يرجى المحاولة مرة أخرى.`,
        hi: `खुशी है, एक त्रुटि हुई: ${error instanceof Error ? error.message : 'अज्ञात त्रुटि'}। कृपया पुनः प्रयास करें।`
      };
      
      const errorMessage: Message = {
        id: generateId(),
        text: errorMessages[currentLanguage] || errorMessages.es,
        isUser: false,
        timestamp: Date.now(),
      };

      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleLanguageChange = (languageCode: string) => {
    setCurrentLanguage(languageCode);
    setAutoDetect(false);
  };

  const toggleAutoDetect = () => {
    setAutoDetect(!autoDetect);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-4xl h-[90vh] bg-white rounded-3xl shadow-2xl flex flex-col overflow-hidden border border-gray-100">
        {/* Header */}
        <div className="relative bg-gradient-to-r from-blue-600 via-blue-700 to-purple-700 text-white px-6 py-6">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <MessageSquare size={32} className="text-white" />
                <Sparkles size={16} className="absolute -top-1 -right-1 text-yellow-300 animate-pulse" />
              </div>
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">MultiChat Pro</h1>
                <p className="text-sm opacity-90 font-medium">Mensajería inteligente multiidioma</p>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <Globe size={20} className="text-white/80" />
              <LanguageSelector
                currentLanguage={currentLanguage}
                onLanguageChange={handleLanguageChange}
                autoDetect={autoDetect}
                onToggleAutoDetect={toggleAutoDetect}
              />
            </div>
          </div>
          
          {/* Decorative elements */}
          <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none">
            <div className="absolute -top-4 -left-4 w-24 h-24 bg-white/10 rounded-full blur-xl"></div>
            <div className="absolute -bottom-4 -right-4 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
          </div>
        </div>

        {/* Language indicator */}
        {autoDetect && (
          <div className="px-6 py-2 bg-blue-50 border-b border-blue-100">
            <div className="flex items-center gap-2 text-sm text-blue-700">
              <Globe size={14} />
              <span>Detección automática: {supportedLanguages[currentLanguage]?.name}</span>
            </div>
          </div>
        )}

        {/* Chat Window */}
        <ChatWindow messages={messages} currentLanguage={currentLanguage} />

        {/* Chat Input */}
        <ChatInput onSendMessage={handleSendMessage} isLoading={isLoading} currentLanguage={currentLanguage} />
      </div>
    </div>
  );
}

export default App;