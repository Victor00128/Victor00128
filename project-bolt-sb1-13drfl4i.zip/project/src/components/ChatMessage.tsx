import React from 'react';
import { User, MessageSquare } from 'lucide-react';
import { Message } from '../types/chat';

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const { text, isUser } = message;

  return (
    <div className={`flex mb-6 ${isUser ? 'justify-end' : 'justify-start'} animate-fadeIn`}>
      <div className={`flex max-w-[80%] ${isUser ? 'flex-row-reverse' : 'flex-row'} items-end gap-3`}>
        <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
          isUser 
            ? 'bg-blue-600 text-white' 
            : 'bg-gray-200 text-gray-600'
        }`}>
          {isUser ? <User size={16} /> : <MessageSquare size={16} />}
        </div>
        
        <div className={`relative px-4 py-3 rounded-2xl shadow-sm max-w-full ${
          isUser
            ? 'bg-blue-600 text-white rounded-br-md'
            : 'bg-white text-gray-800 border border-gray-200 rounded-bl-md'
        }`}>
          <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">
            {text}
          </p>
          <div className={`absolute bottom-0 ${
            isUser 
              ? 'right-0 transform translate-x-1 translate-y-1' 
              : 'left-0 transform -translate-x-1 translate-y-1'
          }`}>
            <div className={`w-3 h-3 transform rotate-45 ${
              isUser ? 'bg-blue-600' : 'bg-white border-r border-b border-gray-200'
            }`}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;