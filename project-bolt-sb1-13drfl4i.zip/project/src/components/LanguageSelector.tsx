import React, { useState } from 'react';
import { ChevronDown, Check, Zap } from 'lucide-react';
import { supportedLanguages } from '../services/languageDetection';

interface LanguageSelectorProps {
  currentLanguage: string;
  onLanguageChange: (languageCode: string) => void;
  autoDetect: boolean;
  onToggleAutoDetect: () => void;
}

const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  currentLanguage,
  onLanguageChange,
  autoDetect,
  onToggleAutoDetect,
}) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleLanguageSelect = (languageCode: string) => {
    onLanguageChange(languageCode);
    setIsOpen(false);
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-all duration-200 text-sm font-medium"
      >
        <span>{supportedLanguages[currentLanguage]?.name || 'Español'}</span>
        <ChevronDown size={16} className={`transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full right-0 mt-2 w-64 bg-white rounded-xl shadow-2xl border border-gray-200 z-50 overflow-hidden">
          {/* Auto-detect toggle */}
          <div className="p-3 border-b border-gray-100">
            <button
              onClick={() => {
                onToggleAutoDetect();
                setIsOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 ${
                autoDetect 
                  ? 'bg-blue-50 text-blue-700 border border-blue-200' 
                  : 'hover:bg-gray-50 text-gray-700'
              }`}
            >
              <Zap size={16} className={autoDetect ? 'text-blue-600' : 'text-gray-400'} />
              <span className="text-sm font-medium">Detección automática</span>
              {autoDetect && <Check size={16} className="ml-auto text-blue-600" />}
            </button>
          </div>

          {/* Language list */}
          <div className="max-h-64 overflow-y-auto">
            {Object.entries(supportedLanguages).map(([code, config]) => (
              <button
                key={code}
                onClick={() => handleLanguageSelect(code)}
                className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 transition-colors duration-150 ${
                  currentLanguage === code && !autoDetect ? 'bg-blue-50 text-blue-700' : 'text-gray-700'
                }`}
              >
                <span className="text-sm font-medium">{config.name}</span>
                {currentLanguage === code && !autoDetect && (
                  <Check size={16} className="ml-auto text-blue-600" />
                )}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setIsOpen(false)}
        />
      )}
    </div>
  );
};

export default LanguageSelector;