import React, { useRef, useEffect } from 'react';
import { MessageCircle } from 'lucide-react';
import ChatMessage from './ChatMessage';
import { Message } from '../types/chat';

interface ChatWindowProps {
  messages: Message[];
  currentLanguage: string;
}

const welcomeMessages: Record<string, { title: string; subtitle: string }> = {
  es: {
    title: '¡Hola! Bienvenido a MultiChat Pro',
    subtitle: 'Puedes escribir en cualquier idioma. Nuestro sistema detectará automáticamente tu idioma y responderá en consecuencia.'
  },
  en: {
    title: 'Hello! Welcome to MultiChat Pro',
    subtitle: 'You can write in any language. Our system will automatically detect your language and respond accordingly.'
  },
  fr: {
    title: 'Bonjour ! Bienvenue sur MultiChat Pro',
    subtitle: 'Vous pouvez écrire dans n\'importe quelle langue. Notre système détectera automatiquement votre langue et répondra en conséquence.'
  },
  de: {
    title: 'Hallo! Willkommen bei MultiChat Pro',
    subtitle: 'Sie können in jeder Sprache schreiben. Unser System erkennt automatisch Ihre Sprache und antwortet entsprechend.'
  },
  it: {
    title: 'Ciao! Benvenuto su MultiChat Pro',
    subtitle: 'Puoi scrivere in qualsiasi lingua. Il nostro sistema rileverà automaticamente la tua lingua e risponderà di conseguenza.'
  },
  pt: {
    title: 'Olá! Bem-vindo ao MultiChat Pro',
    subtitle: 'Você pode escrever em qualquer idioma. Nosso sistema detectará automaticamente seu idioma e responderá adequadamente.'
  },
  ru: {
    title: 'Привет! Добро пожаловать в MultiChat Pro',
    subtitle: 'Вы можете писать на любом языке. Наша система автоматически определит ваш язык и ответит соответственно.'
  },
  zh: {
    title: '你好！欢迎使用 MultiChat Pro',
    subtitle: '您可以用任何语言书写。我们的系统将自动检测您的语言并相应地回复。'
  },
  ja: {
    title: 'こんにちは！MultiChat Pro へようこそ',
    subtitle: 'どの言語でも書くことができます。私たちのシステムは自動的にあなたの言語を検出し、それに応じて応答します。'
  },
  ko: {
    title: '안녕하세요! MultiChat Pro에 오신 것을 환영합니다',
    subtitle: '어떤 언어로든 쓸 수 있습니다. 저희 시스템이 자동으로 귀하의 언어를 감지하고 그에 따라 응답합니다.'
  },
  ar: {
    title: 'مرحباً! أهلاً بك في MultiChat Pro',
    subtitle: 'يمكنك الكتابة بأي لغة. سيقوم نظامنا بكشف لغتك تلقائياً والرد وفقاً لذلك.'
  },
  hi: {
    title: 'नमस्ते! MultiChat Pro में आपका स्वागत है',
    subtitle: 'आप किसी भी भाषा में लिख सकते हैं। हमारा सिस्टम स्वचालित रूप से आपकी भाषा का पता लगाएगा और तदनुसार जवाब देगा।'
  }
};

const ChatWindow: React.FC<ChatWindowProps> = ({ messages, currentLanguage }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const welcome = welcomeMessages[currentLanguage] || welcomeMessages.es;

  return (
    <div className="flex-1 overflow-hidden bg-gradient-to-b from-gray-50 to-white">
      <div className="h-full overflow-y-auto px-6 py-6">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
            <MessageCircle size={48} className="mb-4 opacity-30" />
            <h3 className="text-lg font-medium mb-2">{welcome.title}</h3>
            <p className="text-sm text-center max-w-md opacity-75">
              {welcome.subtitle}
            </p>
          </div>
        ) : (
          <>
            {messages.map((message) => (
              <ChatMessage key={message.id} message={message} />
            ))}
          </>
        )}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};

export default ChatWindow;