export interface LanguageConfig {
  code: string;
  name: string;
  systemPrompt: string;
}

export const supportedLanguages: Record<string, LanguageConfig> = {
  es: {
    code: 'es',
    name: 'Español',
    systemPrompt: 'Responde siempre en español. Eres un asistente útil y amigable que ayuda a los usuarios con sus preguntas y tareas.'
  },
  en: {
    code: 'en',
    name: 'English',
    systemPrompt: 'Always respond in English. You are a helpful and friendly assistant that helps users with their questions and tasks.'
  },
  fr: {
    code: 'fr',
    name: 'Français',
    systemPrompt: 'Réponds toujours en français. Tu es un assistant utile et amical qui aide les utilisateurs avec leurs questions et tâches.'
  },
  de: {
    code: 'de',
    name: 'Deutsch',
    systemPrompt: 'Antworte immer auf Deutsch. Du bist ein hilfsreicher und freundlicher Assistent, der Benutzern bei ihren Fragen und Aufgaben hilft.'
  },
  it: {
    code: 'it',
    name: 'Italiano',
    systemPrompt: 'Rispondi sempre in italiano. Sei un assistente utile e amichevole che aiuta gli utenti con le loro domande e compiti.'
  },
  pt: {
    code: 'pt',
    name: 'Português',
    systemPrompt: 'Responda sempre em português. Você é um assistente útil e amigável que ajuda os usuários com suas perguntas e tarefas.'
  },
  ru: {
    code: 'ru',
    name: 'Русский',
    systemPrompt: 'Всегда отвечай на русском языке. Ты полезный и дружелюбный помощник, который помогает пользователям с их вопросами и задачами.'
  },
  zh: {
    code: 'zh',
    name: '中文',
    systemPrompt: '始终用中文回答。你是一个有用且友好的助手，帮助用户解决问题和任务。'
  },
  ja: {
    code: 'ja',
    name: '日本語',
    systemPrompt: '常に日本語で回答してください。あなたは親切でフレンドリーなアシスタントで、ユーザーの質問やタスクをサポートします。'
  },
  ko: {
    code: 'ko',
    name: '한국어',
    systemPrompt: '항상 한국어로 답변하세요. 당신은 사용자의 질문과 작업을 도와주는 유용하고 친근한 어시스턴트입니다.'
  },
  ar: {
    code: 'ar',
    name: 'العربية',
    systemPrompt: 'أجب دائماً باللغة العربية. أنت مساعد مفيد وودود يساعد المستخدمين في أسئلتهم ومهامهم.'
  },
  hi: {
    code: 'hi',
    name: 'हिन्दी',
    systemPrompt: 'हमेशा हिंदी में जवाब दें। आप एक सहायक और मित्रवत सहायक हैं जो उपयोगकर्ताओं के प्रश्नों और कार्यों में मदद करते हैं।'
  }
};

export class LanguageDetector {
  private static languagePatterns: Record<string, RegExp[]> = {
    es: [
      /\b(hola|gracias|por favor|cómo|qué|cuándo|dónde|por qué|sí|no|bueno|malo)\b/i,
      /\b(español|castellano|hablar|decir|hacer|tener|ser|estar)\b/i,
      /[ñáéíóúü]/
    ],
    en: [
      /\b(hello|hi|thank you|thanks|please|how|what|when|where|why|yes|no|good|bad)\b/i,
      /\b(english|speak|say|do|have|be|is|are|was|were)\b/i,
      /\b(the|and|or|but|if|then|this|that|these|those)\b/i
    ],
    fr: [
      /\b(bonjour|salut|merci|s'il vous plaît|comment|quoi|quand|où|pourquoi|oui|non|bon|mauvais)\b/i,
      /\b(français|parler|dire|faire|avoir|être|est|sont|était|étaient)\b/i,
      /[àâäéèêëïîôöùûüÿç]/
    ],
    de: [
      /\b(hallo|danke|bitte|wie|was|wann|wo|warum|ja|nein|gut|schlecht)\b/i,
      /\b(deutsch|sprechen|sagen|machen|haben|sein|ist|sind|war|waren)\b/i,
      /[äöüß]/
    ],
    it: [
      /\b(ciao|grazie|prego|come|cosa|quando|dove|perché|sì|no|buono|cattivo)\b/i,
      /\b(italiano|parlare|dire|fare|avere|essere|è|sono|era|erano)\b/i,
      /[àèéìíîòóù]/
    ],
    pt: [
      /\b(olá|oi|obrigado|obrigada|por favor|como|o que|quando|onde|por que|sim|não|bom|mau)\b/i,
      /\b(português|falar|dizer|fazer|ter|ser|estar|é|são|era|eram)\b/i,
      /[ãâáàçéêíóôõú]/
    ],
    ru: [
      /[а-яё]/i,
      /\b(привет|спасибо|пожалуйста|как|что|когда|где|почему|да|нет|хорошо|плохо)\b/i,
      /\b(русский|говорить|сказать|делать|иметь|быть|есть|был|была|были)\b/i
    ],
    zh: [
      /[\u4e00-\u9fff]/,
      /\b(你好|谢谢|请|怎么|什么|什么时候|哪里|为什么|是|不|好|坏)\b/i
    ],
    ja: [
      /[\u3040-\u309f\u30a0-\u30ff\u4e00-\u9faf]/,
      /\b(こんにちは|ありがとう|お願いします|どう|何|いつ|どこ|なぜ|はい|いいえ|良い|悪い)\b/i
    ],
    ko: [
      /[\uac00-\ud7af]/,
      /\b(안녕하세요|감사합니다|부탁합니다|어떻게|무엇|언제|어디|왜|네|아니오|좋은|나쁜)\b/i
    ],
    ar: [
      /[\u0600-\u06ff]/,
      /\b(مرحبا|شكرا|من فضلك|كيف|ماذا|متى|أين|لماذا|نعم|لا|جيد|سيء)\b/i
    ],
    hi: [
      /[\u0900-\u097f]/,
      /\b(नमस्ते|धन्यवाद|कृपया|कैसे|क्या|कब|कहाँ|क्यों|हाँ|नहीं|अच्छा|बुरा)\b/i
    ]
  };

  static detectLanguage(text: string): string {
    const cleanText = text.toLowerCase().trim();
    const scores: Record<string, number> = {};

    // Initialize scores
    Object.keys(this.languagePatterns).forEach(lang => {
      scores[lang] = 0;
    });

    // Check patterns for each language
    Object.entries(this.languagePatterns).forEach(([lang, patterns]) => {
      patterns.forEach(pattern => {
        const matches = cleanText.match(pattern);
        if (matches) {
          scores[lang] += matches.length;
        }
      });
    });

    // Find language with highest score
    const detectedLang = Object.entries(scores).reduce((a, b) => 
      scores[a[0]] > scores[b[0]] ? a : b
    )[0];

    // Return detected language if score is above threshold, otherwise default to Spanish
    return scores[detectedLang] > 0 ? detectedLang : 'es';
  }

  static getLanguageConfig(languageCode: string): LanguageConfig {
    return supportedLanguages[languageCode] || supportedLanguages.es;
  }
}