export interface Message {
  id: string;
  text: string;
  isUser: boolean;
  timestamp: number;
}

export interface ChatInputProps {
  onSendMessage: (message: string) => void;
  isLoading: boolean;
}

export interface ChatMessageProps {
  message: Message;
  isUser: boolean;
}

export interface ChatWindowProps {
  messages: Message[];
}